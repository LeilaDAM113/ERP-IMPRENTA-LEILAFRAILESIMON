package com.tfgLeilaFraileSimon.ERP_Imprenta.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.tfgLeilaFraileSimon.ERP_Imprenta.model.Pedido;

public interface PedidoRepository extends JpaRepository<Pedido, Integer> {
}
